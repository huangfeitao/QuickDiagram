// Preprocessing.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{E2D7C522-9A94-435F-8961-BE74E1A31199}", 
		 name = "Preprocessing", 
		 helpstring = "Preprocessing 1.0 Type Library",
		 resource_name = "IDR_PREPROCESSING") ]
class CPreprocessingModule
{
public:
// Override CAtlDllModuleT members
};
		 
