using System;
using System.Collections;
using System.Xml;
using System.Drawing;

namespace Bio
{
    public class Bioclass
    {
        private string id;
        private string name;
        private string name_short; //Short form of the name of this Bio class
        public int maxoutbuone;
        public ArrayList atomList;
        public ArrayList bondList;
        public ArrayList restrictionList;

        //Load variable from external xml
        public Bioclass(XmlNodeReader node)
        {
            id = node.GetAttribute("id");
            atomList = new ArrayList();
            bondList = new ArrayList();
            restrictionList = new ArrayList();
            try
            {
                while (node.Read())
                {
                //collect the attribute informatiom to class information
             
                    #region "Get the name information"
                    //Create the Internal atom list
                    if (node.GetAttribute("id") == "info")
                    {
                        name = node.GetAttribute("name");
                        name_short = node.GetAttribute("sname");
                        maxoutbuone = int.Parse(node.GetAttribute("bone_number"));
                    }
                    #endregion

                    #region "Get the atom information"
                    //Create the Internal atom list
                    if (node.GetAttribute("id") == "element")
                    {
                        atom tempatom = new atom();
                        tempatom.node = node.GetAttribute("node");
                        tempatom.point = node.GetAttribute("point");
                        tempatom.name = node.GetAttribute("element");
                        tempatom.remain = int.Parse(node.GetAttribute("use"));
                        tempatom.used = int.Parse(node.GetAttribute("used"));
                        atomList.Add(tempatom);
                    }
                    #endregion

                    #region "Get the restriction information"
                    if (node.Name == "rules")
                    {
                            atomRestriction tempres = new atomRestriction();
                            tempres.point = node.GetAttribute("point");
                            tempres.value = node.GetAttribute("value");
                            tempres.type = node.GetAttribute("type");
                            restrictionList.Add(tempres);
                    }
                    #endregion

                    #region "Get the inner-bone connection information"
                    //Create the Internal bone list
                    if (node.GetAttribute("id") == "connect")
                    {
                            atomConnection tempcon = new atomConnection();
                            tempcon.inbond = true;
                            tempcon.start_id = "-";
                            tempcon.start_point = "-";
                            tempcon.start_node = int.Parse(node.GetAttribute("start_node"));
                            tempcon.end_id = "-";
                            tempcon.end_point = "-";
                            tempcon.end_node = int.Parse(node.GetAttribute("end_node"));
                            tempcon.bone_number = int.Parse(node.GetAttribute("bone_number"));
                            bondList.Add(tempcon);
                    }
                    #endregion
                }
            }
            catch { }
        }

        //Get which atom is free to use
        public bool checkFull(string point, int bone)
        {
            //check current bone number fullfill the coming bone or not
            if (maxoutbuone < bone)
                return false;
            
            //check bone located at particular point is enough or not
            for (int i=0; i < atomList.Count - 1; i++)
            {
                if (((atom)atomList[i]).remain < bone && ((atom)atomList[i]).point == point)
                {
                    return false;
                }
            }
            return true;
        }

        //Set the atom is used, return 0 if insert fail
        public int connect(string pointID, int boune)
        {
            switch (name)
            {
                case "Benzen_ring":
                    for (int i = 0; i < atomList.Count; i++)
                    {   //handle benzen_ring when connecting point's H is relaesed (remain = 1)
                        if (((atom)atomList[i]).point == pointID && ((atom)atomList[i]).name  == "H" && ((atom)atomList[i]).remain == 0)     //if the pointID is matched
                        {
                            //modified the "H"
                            ((atom)atomList[i]).remain = 1;
                            ((atom)atomList[i]).used = 0;
                            maxoutbuone = maxoutbuone - 1;
                            //modified the internal connection, remove the internal connection with H to C
                            for (int j = 0; j < bondList.Count; j++)
                            {
                                if (((atomConnection)bondList[j]).end_node == int.Parse(((atom)atomList[i]).node))
                                {
                                    bondList.RemoveAt(j);
                                    break;
                                }
                            }
                            for (int j = 0; j < atomList.Count; j++)
                            {
                                if (((atom)atomList[i]).point == pointID && ((atom)atomList[i]).name == "C")
                                    return int.Parse(((atom)atomList[i]).node);
                            }

                        }
                    }
                    return 0;
                default:
                    //start to handle insert case
                    for (int i = 0; i <= atomList.Count - 1; i++)
                    {
                        //if particular point id is used
                        if (((atom)atomList[i]).point == pointID)     //if the pointID is matched
                        {
                            if (((atom)atomList[i]).remain >= boune) //if this point has enough point to connect out
                            {
                                ((atom)atomList[i]).remain = ((atom)atomList[i]).remain - boune;
                                ((atom)atomList[i]).used = ((atom)atomList[i]).used + boune;
                                maxoutbuone = maxoutbuone - boune;
                                return int.Parse(((atom)atomList[i]).node);
                            }
                            else return 0;
                        }
                    }
                    for (int i = 0; i <= atomList.Count - 1; i++)
                    {
                        if (((atom)atomList[i]).remain >= boune)
                        {
                            maxoutbuone = maxoutbuone - boune;
                            ((atom)atomList[i]).remain = ((atom)atomList[i]).remain - boune;
                            ((atom)atomList[i]).used = ((atom)atomList[i]).used + boune;
                            return int.Parse(((atom)atomList[i]).node);
                        }
                    }
                    return 0;
            }
        }

        #region "Get & Set Variable"


        public void SetID(string i)
        {
            id = i;
        }
        public string GetID()
        {
            return id;
        }
        public void SetName(string i)
        {
            name = i;
        }
        public string GetName()
        {
            return name;
        }
        public void SetShortName(string i)
        {
            name_short = i;
        }
        public string GetShortName()
        {
            return name_short;
        }

        #endregion
    }

    public class Biostr
    {

        private Bioclass bio = null;
        private ArrayList itemList; //device list
        private ArrayList connectList; //nodes list

        public Biostr(string instr)
        {
            itemList = new ArrayList();
            connectList = new ArrayList();
            //XMLDocument
            XmlDocument document = new XmlDocument();
            document.LoadXml(instr);

            #region "Read Bio Item"
            XmlNodeList objList1 = document.SelectNodes("//graphicObject");
            foreach (XmlNode objNode in objList1)
            {
                XmlNodeReader objNodeReader = new XmlNodeReader(objNode);

                while (objNodeReader.Read())	//read thru all child nodes of this node
                {
                    if (objNodeReader.NodeType == XmlNodeType.Element)	//	***READING NODES AND DEVICE***
                    {
                        if (objNodeReader.Name == "graphicObject")
                        {
                            bio = new Bioclass(objNodeReader);

                            if (!itemList.Contains(bio))
                            {
                                itemList.Add(bio);
                            }

                        }
                    }
                }
            }
            #endregion

            #region "Read Bio Connection"
            XmlNodeList objList2 = document.SelectNodes("//connection");
            foreach (XmlNode objNode in objList2)
            {
                atomConnection tempcon = new atomConnection();
                XmlNodeReader objNodeReader = new XmlNodeReader(objNode);

                while (objNodeReader.Read())	//read thru all child nodes of this node
                {
                    if (objNodeReader.NodeType == XmlNodeType.Element)	//	***READING NODES AND DEVICE***
                    {
                         tempcon.inbond = false;  
                        //get the two devices which connect together
                        if (objNodeReader.Name == "point")
                        {
                            if (tempcon.start_id == null)
                            {
                                tempcon.start_id = objNodeReader.GetAttribute("objectID");	    // Get the start device
                                tempcon.start_point = objNodeReader.GetAttribute("pointID");     // Get the start point
                            }
                            else if (tempcon.end_id == null)
                            {
                                tempcon.end_id = objNodeReader.GetAttribute("objectID");	// Get the end device ID
                                tempcon.end_point = objNodeReader.GetAttribute("pointID");     // Get the end point
                            }
                        }
                        //get the bond value
                        if (objNodeReader.Name == "Variable")
                        {
                            tempcon.bone_number = int.Parse(objNodeReader.GetAttribute("line_value"));	
                        }
                        //compete convert connnection process
                        if (!connectList.Contains(tempcon) && tempcon.start_id != null && tempcon.end_point != null && tempcon.bone_number > 0)
                        {
                            tempcon.start_node = insertByID(tempcon.start_id, tempcon.bone_number, tempcon.start_point);
                            tempcon.end_node = insertByID(tempcon.end_id, tempcon.bone_number, tempcon.end_point);
                            connectList.Add(tempcon);
                            tempcon = new atomConnection();
                            break;
                        }
                    }
                }
            }
            #endregion

        }

        //connect with ID
        private int insertByID(string id, int bound, string ptID)
        {
            if (itemList != null)
            {
                for (int i=0; i<=itemList.Count - 1; i++)
                {
                    if (((Bioclass)itemList[i]).GetID() == id)
                        return ((Bioclass)itemList[i]).connect(ptID, bound);
                }
            }
            return 0;
        }

        //understand - display info
        public void displayinfo()
        {
            string temp = cal_com() + "\n\n";
           temp = temp + "== BIO item == \n\n";
            for (int i =0; i <= itemList.Count -1; i++)
            {
                if (((Bioclass)itemList[i]).GetName() != "-")
                    temp = temp + ((Bioclass)itemList[i]).GetShortName() + "  " + ((Bioclass)itemList[i]).maxoutbuone + "\n";
            }

            temp = temp + "\n== out boune connection == \n\n";
            for (int i = 0; i <= connectList.Count -1; i ++)
            {
                for (int j = 0; j <= itemList.Count - 1; j++)
                {
                    if (((Bioclass)itemList[j]).GetID() == ((atomConnection)connectList[i]).start_id)
                    {
                        temp = temp + "From " + ((Bioclass)itemList[j]).GetShortName() + " ";
                        break;
                    }
                }

                for (int j = 0; j <= itemList.Count - 1; j++)
                {
                    if (((Bioclass)itemList[j]).GetID() == ((atomConnection)connectList[i]).end_id)
                    {
                        temp = temp +  "to " + ((Bioclass)itemList[j]).GetShortName() + "\n";
                        break;
                    }
                }
            }
            System.Windows.Forms.MessageBox.Show(temp);
        }

        private string cal_com()
        {
            ArrayList mlist = new ArrayList();
            for (int i = 0; i <= itemList.Count - 1; i++)
            {
                ArrayList t1 = ((Bioclass)itemList[i]).atomList;
                for (int j = 0; j <= t1.Count - 1; j++)
                {
                    atom t2 = (atom)t1[j];
                    if (t2.used > 0)
                        mlist.Add(t2.name);
                }
            }
            string output = "";
            mlist.Sort();
            ArrayList finallist = new ArrayList();
            for (int i = 0; i <= mlist.Count - 1; i++)
            {
                int j;
                for ( j = 0; j < finallist.Count; j++)
                {
                    if ((string)mlist[i] == ((atomcount)finallist[j]).name)
                    {
                        ((atomcount)finallist[j]).number = ((atomcount)finallist[j]).number + 1;
                        break;
                    }
                }
                if (j >= finallist.Count)
                {
                    finallist.Add(new atomcount((string)mlist[i], 1));
                }
            }
            for (int i = 0; i <= finallist.Count - 1; i++)
            {
                output = output + ((atomcount)finallist[i]).name;
                if (((atomcount)finallist[i]).number  > 1)
                    output = output + ((atomcount)finallist[i]).number.ToString();
            }
            return output;
        }

        private class atomcount
        {
            public string name;
            public int number;
            public atomcount(string name, int number)
            {
                this.name = name;
                this.number = number;
            }
        }


        //check restriction inteface
        public bool checkres(GOMLib.GOM_Link link)
        {
            string id1 = link.m_startObj.id;
            string id2 = link.m_endObj.id;
            //get the two bio class for checking by their id
            Bioclass Bio1 =null, Bio2 =null;
            for (int i = 0; i < itemList.Count; i++)
            {
                if (((Bioclass)itemList[i]).GetID() == id1)
                    Bio1 = ((Bioclass)itemList[i]);
                if (((Bioclass)itemList[i]).GetID() == id2)
                    Bio2 = ((Bioclass)itemList[i]);
                if (Bio1 != null && Bio2 != null)
                    break;
            }

            if (Bio1 == null || Bio2 == null )
                return true;

            //Start Checking
            bool check1, check2;
            if (Bio1 != null && Bio2 != null)
            {
                check1 = check_Start(Bio1, Bio2,link);
                check2 = check_Start(Bio2, Bio1, link);
                return (check1 && check2);
            }
            return false;
        }

        //check restriction
        private bool check_Start(Bioclass obj_check, Bioclass obj_temp, GOMLib.GOM_Link link)
        {
            for (int i = 0; i < obj_check.restrictionList.Count; i++)
            {
                atomRestriction tempres = (atomRestriction)obj_check.restrictionList[i];
                switch (tempres.type)
                {
                    case "connect_point":
                        if (tempres.point != link.m_startPt.id && tempres.point != link.m_endPt.id)
                            break;
                        string temp_PT = "";
                        if (link.m_startObj.id == obj_check.GetID())
                            temp_PT = link.m_startPt.id;
                        if (link.m_endObj.id == obj_check.GetID())
                            temp_PT = link.m_endPt.id;
                   
                        switch (obj_check.GetName())
                        {
                            case "Benzen_ring":
                                if (link.link_value > 1) return false;
                                for (int j=0; j < obj_check.atomList.Count; j++)
                                {   //handle benzen_ring when connecting point's H is relaesed (remain = 1)
                                    if (((atom)obj_check.atomList[j]).point == temp_PT && ((atom)obj_check.atomList[j]).name == "H" && ((atom)obj_check.atomList[j]).remain == 1)
                                        return false;
                                }
                                break;
                            default:
                                for (int j = 0; j < obj_check.atomList.Count; j++)
                                {
                                    if (((atom)obj_check.atomList[j]).point == temp_PT && ((atom)obj_check.atomList[i]).remain < link.link_value)
                                        return false;
                                }
                                break;
                            }
                        break;
                }//end main switch
            }
            return true;
        }

        //check when bond style change
        public bool check_LinkChange(GOMLib.GOM_Link link)
        {
            bool tem_return = true;
            for (int i = 0; i < connectList.Count; i++)
            {

                if ((((atomConnection)connectList[i]).start_id == link.m_startObj.id && ((atomConnection)connectList[i]).end_id == link.m_endObj.id) || (((atomConnection)connectList[i]).start_id == link.m_endObj.id && ((atomConnection)connectList[i]).end_id == link.m_startObj.id))
                {
                    int tempvalue = link.link_value;    //backup the value
                    link.link_value = link.link_value - ((atomConnection)connectList[i]).bone_number;
                    if (link.link_value > 0)
                    {
                        tem_return = checkres(link);
                    }
                    link.link_value = tempvalue; //restore back the value;
                    return tem_return;
                }
            }
            return tem_return;
        }

    }

    public class atom
    {
        public string point;
        public string node;
        public string name;
        public int used;
        public int remain;
    }

    public class atomConnection
    {
        public string start_id;
        public int start_node;
        public string start_point;
        public string end_id;
        public int end_node;
        public string end_point;
        public int bone_number;
        public bool inbond = true;
    }

    public class atomRestriction
    {
        public string type;
        public string point;
        public string value;
    }
    
}
