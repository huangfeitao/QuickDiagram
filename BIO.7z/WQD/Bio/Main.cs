﻿using System;

namespace Bio
{

    public class main
    {
        public static void Main(string[] args)
        {
        }
    }
}
