// Recognition.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{5D5D945F-D0C4-4E3C-8219-2F5DF88990EB}", 
		 name = "Recognition", 
		 helpstring = "Recognition 1.0 Type Library",
		 resource_name = "IDR_RECOGNITION") ]
class CRecognitionModule
{
public:
// Override CAtlDllModuleT members
};
		 
