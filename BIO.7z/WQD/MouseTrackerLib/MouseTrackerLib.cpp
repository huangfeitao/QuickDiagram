// MouseTrackerLib.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{5E5E03A5-C762-407B-972A-0048D0CB4391}", 
		 name = "MouseTrackerLib", 
		 helpstring = "MouseTrackerLib 1.0 Type Library",
		 resource_name = "IDR_MOUSETRACKERLIB") ]
class CMouseTrackerLibModule
{
public:
// Override CAtlDllModuleT members
};
		 
