// StrokeRefineLib.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{AA605D00-E911-46C5-9FC6-7780C334F57F}", 
		 name = "StrokeRefineLib", 
		 helpstring = "StrokeRefineLib 1.0 Type Library",
		 resource_name = "IDR_STROKEREFINELIB") ]
class CStrokeRefineLibModule
{
public:
// Override CAtlDllModuleT members
};
		 
