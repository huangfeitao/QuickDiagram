using System;

namespace EEDomain
{
	
	public class main
	{
		public static void Main(string[] args)
		{	
		}
	}
}
